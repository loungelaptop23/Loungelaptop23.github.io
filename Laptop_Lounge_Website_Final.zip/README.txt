LAPTOP LOUNGE WEBSITE

1. Open index.html in a browser to preview the website.
2. Replace:
   - YOUR SHOP ADDRESS
   - YOUR BUSINESS HOURS
   - YOUR PHONE NUMBER
   - YOUR WHATSAPP NUMBER
   - @YOUR_INSTAGRAM_ID
   - 91XXXXXXXXXX in the WhatsApp button
3. Upload index.html to your hosting provider.

This is the first responsive version. It can be customized with your real logo, photos, Google Maps link, WhatsApp number, Instagram, reviews and domain.
